# Playbook (Logic App) — `Enrich-MDCAI-ATLAS`

Trigger: **Microsoft Sentinel incident** (invocado por Automation Rule, ver abajo).
Identidad: Managed Identity con rol *Microsoft Sentinel Responder* en el workspace y *Log Analytics Reader*.

## Flujo

| # | Acción | Detalle |
|---|--------|---------|
| 1 | **Entities – Get Alerts** (conector Sentinel) | Obtener alertas del incidente. |
| 2 | **Filter array** | `ProductName == "Azure Security Center"` y `AlertType startsWith "AI.Azure_"`. |
| 3 | **Run query and list results** (Azure Monitor Logs) | `_GetWatchlist('MDCAI_ATLAS_OWASP') \| where SearchKey in (<lista AlertType>)` → devuelve ATLAS_Tactics, ATLAS_Techniques, OWASP_LLM_2025, Confidence, Analyst_Guidance. |
| 4 | **For each** fila | Construir arrays de tags: `ATLAS:<técnica>` por cada técnica (split `;`), `OWASP:<id>` por cada id, `ATLAS-Tactic:<táctica>`, `AI-Threat`, `Mapping-Confidence:<nivel>`. |
| 5 | **Update incident** (Sentinel) | Añadir **Tags** (union de los arrays, deduplicados). Opcional: elevar severidad si Confidence == High y técnica ∈ {AML.T0057, AML.T0055}. |
| 6 | **Add comment to incident (V3)** | Comentario HTML con tabla: Alerta · ATLAS táctica/técnica (link `https://atlas.mitre.org/techniques/<id>`) · OWASP (link `https://genai.owasp.org/llmrisk/<id>`) · Guía para el analista · Nota: "Mapeo propuesto, no oficial de Microsoft". |
| 7 | **Add task to incident** (Sentinel – Incident tasks) | Una tarea por recomendación de `Analyst_Guidance` (p.ej. "Rotar credenciales expuestas", "Revisar índice RAG"). |
| 8 | *(Opcional)* **HTTP POST → Logs Ingestion API (DCR)** | Escribir fila en `MDCAI_Enrichment_CL` (IncidentNumber, SystemAlertId, ATLAS_*, OWASP_*, timestamp) para reporting/auditoría de enriquecimiento. |

## Automation Rule que lo dispara

- **Trigger:** When incident is created *(y opcional: when incident is updated → alerts added)*.
- **Condiciones:** `Alert product names` contains *Microsoft Defender for Cloud*; **y** `Alert name`/`Analytic rule name` contains *AI* (o Tactics contains …). Más preciso: condición sobre *Custom details* `Original_AlertType` startsWith `AI.Azure_` si usás la analytics rule 02.
- **Acciones (en orden):** 1) Add tags `AI-Threat`, `MDC-AI`; 2) Run playbook `Enrich-MDCAI-ATLAS`; 3) Assign owner → cola *AI Security*; 4) *(si usás la regla 02)* Change status → Closed / Classification *Undetermined* con comentario "Superseded by enriched incident" **solo** para el incidente MDC original.
- **Orden:** poner esta regla con orden bajo (ej. 10) para que se ejecute antes de reglas de triage generales.

## Variante sin playbook (cero costo)

Si se usa la **analytics rule 02**, los campos ATLAS/OWASP ya están en *Custom details* y en título/descripción; una **automation rule** puede añadir tags estáticos por condición (`Custom details: OWASP_LLM contains LLM01 → tag OWASP:LLM01`, etc.). Es menos flexible (una regla por tag) pero no requiere Logic App.

## Validación

1. Generar alerta de prueba: en Defender for Cloud > Security alerts > **Sample alerts** → plan *AI Services* (genera `AI.Azure_*` de demo).
2. Verificar en `SecurityAlert` (ProviderName "Azure Security Center") y en `MDCAI_Enriched()` que ATLAS_Techniques ≠ UNMAPPED.
3. Verificar en el incidente: tags `ATLAS:AML.T0054`, `OWASP:LLM01`, comentario y tareas.
4. Query 3.8 (reporting por tags) devuelve filas.
