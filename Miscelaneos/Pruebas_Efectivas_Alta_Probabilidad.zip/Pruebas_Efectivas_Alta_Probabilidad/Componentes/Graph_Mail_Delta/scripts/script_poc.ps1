# Ejemplo conceptual de URI; no autenticado. No solicitar body ni contentBytes.
$base = 'https://graph.microsoft.com/v1.0/users/{user}/mailFolders/{folder}/messages/delta'
$select = '?$select=id,internetMessageId,subject,sender,toRecipients,receivedDateTime,sentDateTime,hasAttachments'
Write-Host ($base + $select)
Write-Host 'Para attachments: /messages/{id}/attachments?$select=id,name,contentType,size,isInline'
Write-Host 'Crear/recrear subscription con Prefer: IdType="ImmutableId".'
