# Fuentes y límites de la evidencia

- [https://learn.microsoft.com/en-us/graph/outlook-change-notifications-overview](https://learn.microsoft.com/en-us/graph/outlook-change-notifications-overview)
- [https://learn.microsoft.com/en-us/graph/delta-query-overview](https://learn.microsoft.com/en-us/graph/delta-query-overview)
- [https://learn.microsoft.com/en-us/graph/outlook-immutable-id](https://learn.microsoft.com/en-us/graph/outlook-immutable-id)
- [https://learn.microsoft.com/en-us/graph/outlook-large-attachments#step-4-optional-get-the-file-attachment-from-the-outlook-item](https://learn.microsoft.com/en-us/graph/outlook-large-attachments#step-4-optional-get-the-file-attachment-from-the-outlook-item)
- [https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access)

La guía de Microsoft describe capacidad y configuración. No demuestra cobertura de la combinación exacta del tenant, versión de QRadar, volumen, red, permisos, ni obligación legal.
