# Opción 5 — Microsoft Graph Mail por buzón (webhooks/delta)

**Fecha de investigación:** 17 de noviembre de 2026. **Estado:** diseño para validación; no se ejecutaron cambios en el tenant ni en QRadar.

## Veredicto breve

Útil solo como complemento para identificar el objeto Exchange o cubrir mensajes ya depositados en buzones. No es un registro de transporte y no ve rechazados, bloqueados, cuarentena ni mensajes sin entrega.

## Alcance que cubre

Objetos de Inbox/Sent Items/otros folders, IDs inmutables opcionales, `hasAttachments` y metadata de cada attachment usando `$select` que excluya `contentBytes`.

## Límites críticos

Permisos de aplicación Mail.Read amplios y sensibles; Application Access Policy puede limitar buzones. Delta tokens expiran. `hasAttachments` no equivale a todos los adjuntos inline por sí solo. Webhook a escala implica renovación de suscripciones, consultas posteriores, throttling y deduplicación por copia/buzón.

## Arquitectura

```mermaid
flowchart LR
 G[Graph Change Notifications] --> W[Webhook/Queue]
 W --> D[Delta por mailbox/folder]
 D --> M[GET message metadata]
 M --> A[GET attachments metadata sin contentBytes]
 A --> N[Normalizar por immutable ID]
 N --> R[Repositorio] --> Q[QRadar]
```

## Paso a paso

1. Resolver si el ID del objeto y el inventario de elementos de buzón son realmente obligatorios; si no, preferir Defender.
2. Crear app con Mail.Read mínimo y restringirla a buzones explícitos mediante Exchange Application Access Policy.
3. Crear webhooks por recurso; usar `Prefer: IdType=ImmutableId`; persistir subscription expirations y renovar.
4. Al recibir notificación, ejecutar delta o lectura puntual. Solicitar campos concretos y attachments con `$select`, excluyendo `contentBytes`.
5. Separar copias del mensaje en carpetas/buzones, eventos created/updated/deleted y versiones; no asumir correspondencia uno-a-uno.
6. Conciliar con `EmailEvents` por Internet/Network Message ID cuando exista; mantener Graph como gap-filler.

## Contrato mínimo de datos

- Correo: `NetworkMessageId`, `InternetMessageId`, timestamp, remitente, destinatario, dirección, acción/ubicación de entrega, asunto solo si está aprobado.
- Adjunto: `FileName`, `FileExtension`, `FileType`, `FileSize`, hash si existe; no se usa nombre+tamaño como identidad única.
- Técnica: versión de esquema, tiempo de evento, ingestión y persistencia, partition/offset o cursor, fuente, estado de normalización.
- Exclusiones por defecto: cuerpo, `bodyPreview`, contenido binario, MIME completo, fragmentos DLP y datos no aprobados en `AdditionalFields`.

## Operación, seguridad y recuperación

- Identidades administradas o certificados; mínimo privilegio; secretos en Key Vault; red privada cuando sea compatible.
- Consumidor idempotente; checkpoint después de persistir; cuarentena de errores; replay documentado; alertas por lag/ausencia/diferencia de conteos.
- Separar staging mutable, dataset curado y archivo WORM. No escribir directamente en un contenedor WORM antes de validar reintentos y semántica de append.
- Aplicar RBAC, cifrado, logging, borrado al vencimiento, legal hold y retención según decisión aprobada de Legal/Compliance.

## Criterios de PoC

1. Mensaje sintético inbound, outbound e intra-org con dos adjuntos, inline, cloud/reference, cifrado si aplica y mensaje adjunto.
2. Contraste exacto entre control de entrada, origen, QRadar y repositorio; no usar `dcount` para certificar.
3. Latencia, duplicados, reordenamiento, caída/reinicio, replay, cambio de esquema, campos no autorizados, nombres con caracteres especiales.
4. Evidencia de cobertura de adjuntos, hash efectivo, reglas QRadar y recuperación de un registro histórico.
5. No avanzar a producción si hay pérdida no explicada, contenido no autorizado, privilegios excesivos o retención no definida.

## Archivos auxiliares

- `consultas.kql`: validación en Hunting cuando aplica.
- `script_poc.ps1`: extracción de parámetros y ejemplo orientativo; no contiene credenciales.
- `matriz_cobertura.csv`: casos de prueba.

## Fuentes Microsoft Learn consultadas

- [https://learn.microsoft.com/en-us/graph/outlook-change-notifications-overview](https://learn.microsoft.com/en-us/graph/outlook-change-notifications-overview)
- [https://learn.microsoft.com/en-us/graph/delta-query-overview](https://learn.microsoft.com/en-us/graph/delta-query-overview)
- [https://learn.microsoft.com/en-us/graph/outlook-immutable-id](https://learn.microsoft.com/en-us/graph/outlook-immutable-id)
- [https://learn.microsoft.com/en-us/graph/outlook-large-attachments#step-4-optional-get-the-file-attachment-from-the-outlook-item](https://learn.microsoft.com/en-us/graph/outlook-large-attachments#step-4-optional-get-the-file-attachment-from-the-outlook-item)
- [https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access)

> Verificación previa a producción: disponibilidad, límites, UI, SKU, licenciamiento y campos pueden cambiar. La documentación oficial no sustituye la PoC del tenant ni la validación del conector QRadar.
