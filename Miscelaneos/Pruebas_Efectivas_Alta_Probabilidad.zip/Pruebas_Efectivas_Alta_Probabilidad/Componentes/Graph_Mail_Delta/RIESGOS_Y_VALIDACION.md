# Riesgos y validación

## Riesgos comunes a decidir antes de construir

| Riesgo | Señal | Mitigación | Gate |
|---|---|---|---|
| Cobertura incompleta | `AttachmentCount` difiere de filas | PoC con corpus; no extrapolar desde nombre de una sola muestra | Bloqueante |
| Contenido excesivo | cuerpo/MIME/fragmentos aparecen crudos | allowlist y DLP de pipeline; borrar staging; revisar logs | Bloqueante |
| Duplicados/versiones | mismo mensaje y múltiples estados | preservar raw; dedup técnico; estado versionado | Bloqueante si altera conteo |
| Reordenamiento | attachment llega antes/después | ventana/correlación y retries | Importante |
| Pérdida al reiniciar | consumer lag o cursor no avanza | checkpoint post-persist, monitor, replay | Bloqueante |
| Esquema cambia | campo/tipo no mapea | contrato, schema fingerprint, cuarentena | Importante |
| QRadar parser | evento aceptado pero no parseado | prueba end-to-end por versión DSM | Bloqueante |
| WORM configurado demasiado pronto | datos/formatos deben corregirse | staging mutable; lock tras aprobación | Bloqueante |
| Retención indefinida | no existe base o periodo | decisión Compliance/Legal + lifecycle | Bloqueante |

## Evidencia mínima a adjuntar a una revisión

- Export de conteos del tenant sin PII sensible.
- Log de corrida, hashes/manifests de archivos sintéticos, no de datos reales.
- Diagrama aprobado, RBAC/identidad y dataflow.
- Resultado de parser QRadar y captura de búsquedas.
- Resultado de replay, fallo, duplicado y cambio de esquema.
- Sign-off Legal/Compliance/Privacy/Security/Operations.
