# Fuentes y límites de la evidencia

- [https://learn.microsoft.com/en-us/powershell/module/exchangepowershell/get-messagetracev2?view=exchange-ps](https://learn.microsoft.com/en-us/powershell/module/exchangepowershell/get-messagetracev2?view=exchange-ps)

La guía de Microsoft describe capacidad y configuración. No demuestra cobertura de la combinación exacta del tenant, versión de QRadar, volumen, red, permisos, ni obligación legal.
