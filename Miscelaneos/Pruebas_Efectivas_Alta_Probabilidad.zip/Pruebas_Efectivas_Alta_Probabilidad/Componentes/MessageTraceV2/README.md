# Opción 6 — Message Trace V2 como reconciliación

**Fecha de investigación:** 17 de noviembre de 2026. **Estado:** diseño para validación; no se ejecutaron cambios en el tenant ni en QRadar.

## Veredicto breve

Útil y ampliamente documentado para transporte, pero no es solución del inventario de nombres de adjuntos. Debe ser control independiente y backstop de conteos/estado.

## Alcance que cubre

Estado de paso por Exchange Online, remitente/destinatario, timestamps e identificadores; búsquedas sobre los últimos 90 días con ventanas acotadas.

## Límites críticos

Hasta 10 días por consulta, máximo 5 000 resultados, 100 solicitudes por ventana de 5 minutos y sin paginación estándar. Por sí solo no produce una fila por nombre/archivo.

## Arquitectura

```mermaid
flowchart LR
 D[Defender telemetría] --> C[Reconciliador]
 T[Get-MessageTraceV2] --> C
 C --> K[Brechas por ID, estado y volumen]
 K --> A[Alertas de datos] 
 K --> H[Informe diario no WORM por sí solo]
```

## Paso a paso

1. Usarlo únicamente después de definir un dataset principal; no sustituir Defender ni Graph Mail.
2. Consultar por intervalos UTC menores o iguales a 10 días y filtros precisos; respetar ResultSize 5 000.
3. Implementar cursor manual con `StartingRecipientAddress` + `EndDate` según el último registro cuando haya resultados parciales.
4. Comparar IDs, estado y conteos agregados; distinguir Expanded, Failed, Quarantined, spam, etc.
5. Persistir manifest de corrida y discrepancias, sin afirmar que ausencia en trace significa ausencia en el servicio fuera de la ventana o por filtros.

## Contrato mínimo de datos

- Correo: `NetworkMessageId`, `InternetMessageId`, timestamp, remitente, destinatario, dirección, acción/ubicación de entrega, asunto solo si está aprobado.
- Adjunto: `FileName`, `FileExtension`, `FileType`, `FileSize`, hash si existe; no se usa nombre+tamaño como identidad única.
- Técnica: versión de esquema, tiempo de evento, ingestión y persistencia, partition/offset o cursor, fuente, estado de normalización.
- Exclusiones por defecto: cuerpo, `bodyPreview`, contenido binario, MIME completo, fragmentos DLP y datos no aprobados en `AdditionalFields`.

## Operación, seguridad y recuperación

- Identidades administradas o certificados; mínimo privilegio; secretos en Key Vault; red privada cuando sea compatible.
- Consumidor idempotente; checkpoint después de persistir; cuarentena de errores; replay documentado; alertas por lag/ausencia/diferencia de conteos.
- Separar staging mutable, dataset curado y archivo WORM. No escribir directamente en un contenedor WORM antes de validar reintentos y semántica de append.
- Aplicar RBAC, cifrado, logging, borrado al vencimiento, legal hold y retención según decisión aprobada de Legal/Compliance.

## Criterios de PoC

1. Mensaje sintético inbound, outbound e intra-org con dos adjuntos, inline, cloud/reference, cifrado si aplica y mensaje adjunto.
2. Contraste exacto entre control de entrada, origen, QRadar y repositorio; no usar `dcount` para certificar.
3. Latencia, duplicados, reordenamiento, caída/reinicio, replay, cambio de esquema, campos no autorizados, nombres con caracteres especiales.
4. Evidencia de cobertura de adjuntos, hash efectivo, reglas QRadar y recuperación de un registro histórico.
5. No avanzar a producción si hay pérdida no explicada, contenido no autorizado, privilegios excesivos o retención no definida.

## Archivos auxiliares

- `consultas.kql`: validación en Hunting cuando aplica.
- `script_poc.ps1`: extracción de parámetros y ejemplo orientativo; no contiene credenciales.
- `matriz_cobertura.csv`: casos de prueba.

## Fuentes Microsoft Learn consultadas

- [https://learn.microsoft.com/en-us/powershell/module/exchangepowershell/get-messagetracev2?view=exchange-ps](https://learn.microsoft.com/en-us/powershell/module/exchangepowershell/get-messagetracev2?view=exchange-ps)

> Verificación previa a producción: disponibilidad, límites, UI, SKU, licenciamiento y campos pueden cambiar. La documentación oficial no sustituye la PoC del tenant ni la validación del conector QRadar.
