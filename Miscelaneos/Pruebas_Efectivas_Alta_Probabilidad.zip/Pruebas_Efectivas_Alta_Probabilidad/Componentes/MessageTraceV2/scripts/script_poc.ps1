param(
 [Parameter(Mandatory)][datetime]$StartUtc,
 [Parameter(Mandatory)][datetime]$EndUtc
)
if (($EndUtc-$StartUtc).TotalDays -gt 10) { throw 'La ventana no puede superar 10 días.' }
# Requiere conexión e identidad Exchange Online autorizada.
# Ejemplo sin credenciales:
Get-MessageTraceV2 -StartDate $StartUtc -EndDate $EndUtc -ResultSize 5000 |
 Select-Object Received,SenderAddress,RecipientAddress,Subject,Status,MessageTraceId,MessageId
