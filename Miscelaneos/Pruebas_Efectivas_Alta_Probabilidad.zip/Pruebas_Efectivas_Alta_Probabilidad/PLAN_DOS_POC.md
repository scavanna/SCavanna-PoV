# Plan de dos pruebas de concepto

## PoC 1 — Principal: Graph post-delivery

- Inbound/internal: Graph Mail en mailbox destinatario.
- Outbound: Graph Sent Items + Message Trace V2.
- Azure: notifications/delta, Queue, Function, Blob, Event Hubs y QRadar.
- Riesgo a medir: object desaparece o se purga antes de Graph.

## PoC 2 — Alternativa híbrida: Defender inbound/internal

- Inbound/internal: Defender XDR `EmailEvents` + `EmailAttachmentInfo` Streaming.
- Outbound: Graph Sent Items + Message Trace V2.
- Azure/QRadar: normalizador común, allowlist, Event Hubs y consumer QRadar.
- Riesgo a medir: cobertura universal de MDO attachment types, delivery-state, latency, hashes y raw metadata.

## Comparación controlada

Usar el mismo corpus, consumidores y esquema normalizado:

1. mensaje normal inbound/internal;
2. inline;
3. reference/cloud;
4. item/message;
5. S/MIME/OME/RMS/wrapper opaco;
6. Inbox rule move/delete/perma-delete;
7. quarantine/release;
8. list/distribution/shared mailbox;
9. dos attachments con mismo nombre y tamaño;
10. outage y replay.

Para cada mensaje registrar:

- control enviado por la prueba;
- resultado Graph;
- resultado Defender;
- delivery state;
- attachment rows;
- tiempo de aparición;
- resultado normalizado;
- QRadar parsed/not parsed;
- requests/costo/GB-s/eventos.

## Gate de decisión

| Dimensión | Preferir Graph | Preferir Defender alternativo |
|---|---|---|
| Cobertura post-delivery + attachment ID | Graph mejor | Solo si MDO demuestra igual o mayor cobertura |
| Regla de borrado/purge | Graph pierde o queda gap | Defender conserva evento pre-mailbox |
| Inbound/internal scale | Graph requiere subscriptions/GETs | Defender streaming reduce esa carga |
| Outbound | Igual: Graph + Message Trace | Igual |
| Costo | Menor si Graph/QA ya operacional | Menor solo si MDO licenciado y reemplaza realmente trabajo Graph |
| Minimización antes del destino | Graph `$select` | MDO stream trae tablas completas; requiere allowlist |
| Latencia | Notifications puede ser más rápido, no garantizado | Puede tardar hasta una hora en Event Hubs |

## Resultado esperado

Mantener como escenario principal el Graph post-delivery. Adoptar la alternativa Defender para inbound/internal si y solo si demuestra menor pérdida frente a purge, cobertura comparable, entrega confiable y costo/latencia aceptables. La decisión final puede ser híbrida: Defender para algunos inboxes o direcciones y Graph para otras; no fusionar ambos sin deduplicación si producen la misma fila lógica.
