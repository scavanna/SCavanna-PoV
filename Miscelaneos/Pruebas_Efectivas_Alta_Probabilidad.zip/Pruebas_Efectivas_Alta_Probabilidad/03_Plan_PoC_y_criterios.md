# Plan corto de prueba y esfuerzo

## Una PoC integrada

No se divide el presupuesto en tres PoC. Se prueba un pipeline único y las diferencias de cada escenario con datos sintéticos.

## Fases

| Fase | Duración indicativa | Objetivo | Salida |
|---|---:|---|---|
| 0. Definición | 1-2 días | Universo, mailboxes, campos, carpeta/retención, QRadar endpoint, Privacy | contrato firmado |
| 1. Graph read | 2-4 días | Permisos, delta, Sent Items, attachments, shared/list | corpus y conteos |
| 2. Azure pipeline | 3-5 días | Functions, Queue, Blob, Event Hub, checkpoints, retries | eventos normalizados |
| 3. Message Trace outbound | 1-2 días | Relación y status real de transporte | outbound reconciliado |
| 4. QRadar end-to-end | 2-4 días | Protocol, DSM/parser, rule, lag, replay | evidencia QRadar |
| 5. Operación/aceptación | 1-2 días | Alertas, RBAC, runbook, costos, gates | go/no-go |

Duración de ejecución efectiva estimada: 8-15 días laborales, sujeta a acceso, aprobaciones QRadar, mailboxes y disponibilidad del conector. Es una estimación de planificación, no compromiso.

## Carga de referencia

- 20.000 mailboxes.
- 50 mensajes/día por mailbox: aproximadamente 1.000.000 mensajes/día y 11,6 mensajes/segundo promedio.
- La prueba debe medir peaks y attachment GETs, no solo el promedio.
- La PoC debe incluir un tramo de escala controlado; extrapolar 20.000 usuarios desde una sola mailbox no es suficiente.

## Recursos mínimos

- app registration con acceso acotado;
- 1 Function App/pipeline, Queue Storage, Blob/State, Event Hubs;
- Log Analytics solo para observabilidad;
- un entorno/consumer group QRadar;
- un conjunto reducido de mailboxes controladas;
- responsables Exchange/Entra, Azure, QRadar, SOC y Privacy/Security.

## Gates de go/no-go

**Go si:**

- Graph devuelve cada attachment observable del corpus sin backlog permanente bajo carga y picos;
- el patrón de subscriptions/renewal y `Retry-After` es operativo para la población acordada;
- QRadar parsea/consulta todos los eventos;
- Message Trace concilia outbound con estado explícito;
- no hay contenido original;
- retry/replay/outage pasan;
- Inbox + Deleted Items + purge inmediato superan la prueba de carrera, o la regla/retención se ajusta para preservar el objeto durante la ventana de captura;
- throttling, renovación de subscriptions, costo y capacidad de recuperación se consideran aceptables a 20.000 mailboxes.

**No-go o rediseño si:**

- mensajes relevantes se eliminan fuera de la ventana y no se puede remediar;
- parser QRadar no puede consumir el formato;
- permisos deben ser globales sin control por mailbox;
- Legal prohíbe metadata/retención definida;
- volumen exige un patrón que no cumple SLA/costo.

## Métodos no probados inicialmente

Defender, Purview/DLP, journaling, Sentinel e `analyzedEmails` beta quedan en `Evaluado_No_Recomendado`. Se reabren solo si cambia una restricción o si la PoC propuesta presenta una brecha material fuera del universo aprobado.
