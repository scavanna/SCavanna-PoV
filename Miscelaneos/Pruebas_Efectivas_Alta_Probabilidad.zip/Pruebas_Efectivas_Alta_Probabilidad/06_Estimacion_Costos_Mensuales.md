# Estimación de costo mensual — USD

**Fecha de referencia:** 18 de noviembre de 2026.  
**Carga base:** 20.000 mailboxes × 50 mensajes/día = 1.000.000 mensajes/día = 30.000.000 mensajes/mes.  
**Tipo de costo:** rango de planificación usando precios públicos pay-as-you-go de Microsoft Azure. No es una cotización ni incluye impuestos, descuentos, convenio Enterprise Agreement/MACC, región, soporte, ingeniería ni QRadar.

## Resultado ejecutivo

| Perfil | Uso Azure mensual estimado | USD/mes aproximado | Cuándo sirve |
|---|---:|---:|---|
| **PoC / mínimo** | Functions Consumption, 1 Event Hubs TU, Storage, observabilidad acotada | **USD 60–180** | PoC corta, mailboxes limitados, sin HA ni private networking |
| **Producción equilibrada** | Functions Flex/Premium o cómputo redundante, 2–4 Event Hubs TU, Blob/Queue, Log Analytics de operación y picos controlados | **USD 300–800** | 20.000 buzones, SLO operativo, retry/replay, sin VNet premium |
| **Producción reforzada** | Funciones Premium multinivel, Event Hubs Premium o 4–8 TU, private networking, mayor retención/monitoreo | **USD 1.000–2.000+** | Mayor HA, aislamiento de red, contingencia y crecimiento |

Estos rangos no representan el costo de QRadar, licencias M365/Exchange/Entra, horas de implementación ni operación SOC. En una organización Microsoft, parte del cómputo puede cubrirse con créditos/beneficios existentes.

## Supuestos para el cálculo

- 30% de los mensajes tienen al menos un attachment: 300.000/día y 9.000.000/mes.
- 1 attachment por cada mensaje con attachment para el escenario base. Se agrega sensibilidad para 1,5.
- Un evento normalizado ocupa 1–2 KB.
- Solo metadata de attachment entra al Event Hub. Las notificaciones y referencias de trabajo son temporales.
- 30–40 millones de ejecuciones/eventos de Function por mes, incluyendo notifications, delta pages y attachment workers. La cifra real depende del patrón de webhook, debounce y paginación.
- QRadar consume el Event Hub con un consumer group propio.
- Blob conserva staging/replay corto. No se está presupuestando archivo regulatorio de 6 años.
- No se descargan bytes de attachments y, por tanto, no hay egress/CPU de hashing.

## Desglose orientativo

| Componente | Estimación mensual | Comentario |
|---|---:|---|
| Microsoft Graph | **USD 0 directo esperado** | El costo está absorbido por las licencias M365 aplicables; no significa “sin límite”. Requiere permisos, throttling y entitlement compatibles. |
| Azure Functions — consumo | **USD 10–120** | Millones de ejecuciones suelen ser baratas; el costo dominante puede ser GB-segundos si las llamadas Graph son lentas. La cota aumenta si no se usan debounce/concurrencia controlada. |
| Azure Functions — Premium EP1 | **aprox. USD 160 por instancia/mes** | Base de referencia pública aproximada; 2 instancias elevan rápidamente el piso. Sin cold start y con VNet. |
| Event Hubs Standard — 1 TU | **aprox. USD 22–23/mes** | Referencia pública de USD 0,03/h por TU Standard. 2 TU ≈ USD 44; 4 TU ≈ USD 88. Debe validarse por picos, particiones y retención. |
| Event Hubs Premium — 1 PU | **≈ USD 900/mes** | Orden de magnitud para 1 Processing Unit de USD 1,233/h; se usa si se requiere Premium, aislamiento/escala. No es la recomendación inicial. |
| Queue/Blob Storage | **USD 5–80** | Pocos GB/mes de staging costarían poco; las operaciones son más relevantes que 10–30 GB de metadata. Retención larga aumenta volumen acumulado. |
| Log Analytics — solo operación | **USD 5–40** | Métricas, errores, lag y pequeñas trazas. Evitar enviar el dataset completo si QRadar ya es el SIEM. |
| Log Analytics — dataset completo de adjuntos | **USD 20–110+** | 9–45 GB/mes × precio Analytics aproximado de USD 2,30/GB. No recomendable duplicarlo sin caso de uso. |
| Key Vault, DNS, egress, networking | **USD 10–150** | Depende de Private Endpoint, VPN, DNS, validación TLS, tráfico y región. |
| QRadar | **A cotizar/validar** | Puede ser marginal si la licencia/EPS está disponible o significativo si requiere EPS, DSM, almacenamiento, appliance/protocolo y soporte adicional. |

## Sensibilidad por cantidad de eventos

| Attachment messages/día | Eventos a QRadar/mes, 1 attachment | Datos aproximados a 1,5 KB/evento | Nota |
|---:|---:|---:|---|
| 100.000 | 3.000.000 | ≈ 4,5 GB | Piloto |
| 300.000 | 9.000.000 | ≈ 13,5 GB | Supuesto base, 30% |
| 500.000 | 15.000.000 | ≈ 22,5 GB | Volumen medio-alto |
| 1.000.000 | 30.000.000 | ≈ 45 GB | Todos los mensajes con attachment |

Si hay 1,5 attachments por mensaje, multiplique filas de salida por 1,5. Las copias Inbox/Sent Items pueden elevar el conteo si se conservan ambas; el diseño debe deduplicar el mismo correo o declarar que mantiene una fila por copia.

## Sensibilidad del escenario alternativo Defender

Si Defender for Office 365 ya está incluido, la alternativa puede reducir la porción variable de Graph y Functions para inbound/internal —subscriptions, delta, `/attachments`, retries y 404—, probablemente entre **20% y 60% de ese componente**, sujeto a medición. Event Hubs, QRadar, storage, outbound y normalización no desaparecen. Si MDO requiere licencia nueva, el ahorro puede neutralizarse o invertirse. Ver `Escenario_Alternativo_Defender/COSTO_DIFERENCIAL.md`.

## Costo de retención

El costo de capacidad Blob para metadata es bajo comparado con Log Analytics o QRadar, pero crece con los años:

- 13,5 GB/mes × 12 meses ≈ 162 GB/año.
- 45 GB/mes × 12 meses ≈ 540 GB/año.
- A 6 años pueden acumularse entre ≈ 1 TB y 3,2 TB antes de compresión, duplicación y réplicas.

Como referencia, Hot Blob publicado ronda el orden de centavos por GB/mes; el costo de operaciones, redundancia, zona/región, lifecycle, legal hold e inmutabilidad puede superar el costo puro de capacidad. Six-year retention requires a separate cost model.

## Principal variable de costo

No es el volumen bruto almacenado; es la combinación de:

1. consultas Graph para delta y attachments;
2. tiempo en ejecución de Functions durante llamadas/reintentos;
3. monitoreo y Log Analytics duplicado;
4. capacidad QRadar/EPS y parser;
5. Event Hubs Premium/private networking si BNA los exige;
6. retención y recuperación a varios años.

## Recomendación de presupuesto

- Para PoC: reservar **USD 500–1.000** como techo técnico temporal, incluyendo margen y telemetría, aunque el consumo esperado sea inferior.
- Para operación: presupuestar inicialmente **USD 500–1.000/mes** para infraestructura Azure estándar y otro rango separado para QRadar, soporte y operación.
- Si se exige Event Hubs Premium, redes privadas completas o alta disponibilidad multinivel: presupuestar **USD 1.500–2.500+/mes** hasta medir el diseño.
- La retención a 6 años y QRadar son partidas aparte; no las ocultar en el subtotal Azure.

## Cómo convertir esto en cotización real

1. Confirmar región Azure, EA/MACC/descuento y acuerdo QRadar.
2. Medir attachment rate, attachments/message, payload real, picos 5-min y 1-h.
3. Medir invocations, duración y GB-s de Functions.
4. Elegir 1/2/4 TU mediante carga o Event Hubs Premium según red/SLA.
5. Decidir Log Analytics: solo operaciones o dataset completo.
6. Modelar Blob por período, lifecycle, redundancia y cantidad de réplicas.
7. Medir QRadar EPS/eventos y almacenamiento.
8. Usar Azure Pricing Calculator y contrato del cliente para la cifra definitiva.

## Fuentes de precios públicas

- [Azure Functions pricing](https://azure.microsoft.com/en-us/pricing/details/functions/)
- [Azure Event Hubs pricing](https://azure.microsoft.com/en-us/pricing/details/event-hubs/)
- [Azure Queue Storage pricing](https://azure.microsoft.com/en-us/pricing/details/storage/queues/)
- [Azure Blob Storage pricing](https://azure.microsoft.com/en-us/pricing/details/storage/blobs/)
- [Azure Monitor pricing](https://azure.microsoft.com/en-us/pricing/details/monitor/)

Los precios varían por región, tipo de suscripción, redundancia y fecha. La página oficial de Azure Pricing Calculator debe prevalecer antes de aprobar presupuesto.
