# Escenario alternativo: Defender for Office 365 para entrante e interno

## Estado

**Prueba alternativa propuesta.** El escenario principal sigue siendo Graph Mail post-delivery + Azure, con Message Trace para outbound. Esta alternativa existe específicamente para reducir el riesgo de pérdida causado por Inbox rules, descarga+borrado o purga inmediata.

## Respuesta ejecutiva

Defender for Office 365 puede reducir materialmente el riesgo porque observa el correo durante el procesamiento de seguridad, antes de que una regla de buzón elimine el objeto. `EmailAttachmentInfo` puede existir aunque el correo desaparezca después del Inbox/Deleted Items. El usuario puede borrar la copia del mailbox, pero no puede borrar retroactivamente el evento ya generado por Defender.

No equivale a garantía universal: Defender registra los correos y adjuntos que observa/procesa y expone mediante sus tablas. No se debe afirmar que rescata todos los archivos posibles, especialmente wrappers cifrados no inspeccionables, reference/cloud/item attachments o formatos no representados. Tampoco permite recuperar el contenido original desde el registro de metadata.

## Alcance del escenario alternativo

| Escenario | Fuente primaria | Criterio |
|---|---|---|
| Inbound | Defender `EmailEvents` + `EmailAttachmentInfo` | Procesado por MDO y con evidencia de entrega a mailbox |
| Intra-org | Defender `EmailEvents` + `EmailAttachmentInfo` | `EmailDirection = Intra-org` y evidencia de entrega a mailbox |
| Outbound | Graph Sent Items + Message Trace V2 | Mantener el método principal; Defender no agrega suficiente valor para el alcance solicitado |

## Arquitectura

```mermaid
flowchart LR
  IN[Inbound mail] --> MDO[Defender for Office 365]
  INT[Internal mail] --> MDO
  MDO --> EE[EmailEvents stream]
  MDO --> EA[EmailAttachmentInfo stream]
  EE --> EH[Defender Streaming -> Event Hubs]
  EA --> EH
  EH --> F[Normalizer allowlist + delivery-state + dedup]
  OUT[Outbound] --> G[Graph Sent Items]
  OUT --> MT[Message Trace V2]
  G --> F
  MT -. transport status .-> F
  F --> ST[Blob replay / normalized metadata]
  F --> QR[QRadar consumer]
```

## Qué recupera o evita perder

Defender puede conservar la observación aunque después ocurra:

- Inbox rule mueve a Deleted Items;
- usuario elimina/perma-delete;
- automation descarga el archivo y borra el correo;
- mensaje deja de estar disponible para Graph en el momento del polling.

La metadata que sí se pretende conservar:

- timestamps y `NetworkMessageId`/`InternetMessageId`;
- remitente;
- recipient resuelto;
- `EmailDirection`;
- delivery action/location observados;
- attachment count;
- `FileName`, `FileType`, `FileExtension`, `FileSize`;
- `SHA256` cuando esté poblado;
- estado de esquema y fuente.

No conserva body, MIME ni bytes del attachment.

## Lo que no resuelve por sí solo

1. **Universalidad:** “procesado/observado por MDO” no significa every attachment format o every possible routing topology.
2. **Hash completo:** `SHA256` suele no estar poblado; el esquema recomienda usar el hash disponible cuando exista.
3. **Objeto de attachment único:** nombre+tamaño no siempre identifica una instancia; `NetworkMessageId` no equivale a attachment object ID de Graph.
4. **Adjuntos cifrados opacos:** puede observarse un wrapper cifrado, pero no necesariamente los archivos internos.
5. **Tipos modernos:** inline, reference/cloud e item/message attachment deben probarse.
6. **Entrega final:** Streaming no incluye `LatestDeliveryAction/Location`; el normalizador debe observar cambios de estado y conservar la evidencia de `Delivered`, o usar una regla de inclusión documentada.
7. **Latencia:** la guía indica que eventos exportados pueden tardar hasta una hora en aparecer en Event Hubs. No debe presentarse como cinco minutos.
8. **Campo completo:** el stream transporta registros de tabla; se debe aplicar allowlist downstream y excluir `Subject`, `AdditionalFields` no aprobados y threat fields si no son requeridos.

## Selección solo de correo entregado

PoC:

1. Conservar `EmailEvents` y `EmailAttachmentInfo` crudos solo durante una ventana técnica.
2. Correlacionar por `NetworkMessageId` + recipient y timestamps.
3. Considerar elegible inbound/internal cuando exista un evento de entrega a ubicación de mailbox aprobada y no sea únicamente blocked/quarantine/failed/dropped.
4. Si hay múltiples actualizaciones, preservar todas y derivar `everDelivered=true` y `latestObservedState` por separado.
5. Validar cómo aparecen mensajes en Deleted Items, Junk, Inbox/Folder y posteriores remediaciones. No descartar `everDelivered` solo porque luego se elimina.
6. Enviar a QRadar la fila normalizada solo después de que la política de entrega está determinada; conservar `statePending` si el estado aún no es concluyente.

## Mitigación de la carrera de borrado

| Caso | Graph principal | Defender alternativo |
|---|---|---|
| Inbox rule mueve a Deleted Items | Puede capturar si rastrea ambas carpetas | Defender ya puede tener evento antes del movimiento |
| Delete permanente inmediato | Puede perder por 404 | Riesgo mucho menor; el stream no depende de existencia actual del mailbox object |
| Se descarga attachment y se elimina correo | Puede perder | Defender conserva metadata observada, no el archivo |
| Worker/notification caído | Delta puede recuperar si el objeto existe | Event Hub + Capture permite recuperación temporal de stream |

El beneficio es independencia respecto de la vida del objeto del buzón. No es respaldo del contenido original.

## QRadar

QRadar conserva el mismo patrón de integración:

- Defender Streaming → Event Hub;
- normalizador/allowlist → Event Hub curado o consumer directo si el formato y DSM son validados;
- consumer group específico de QRadar;
- Blob staging/replay separado;
- una fila de attachment por `NetworkMessageId/recipient/source occurrence`;
- Message Trace solo para reconciliación outbound, no para attachment details.

Para comparar con Graph, los dos escenarios deben producir un esquema común antes de llegar a QRadar.

## Efecto sobre el costo

Defender puede reducir costo operativo Azure al eliminar, para inbound/internal:

- subscriptions y renewals por carpetas/buzones de esos escenarios;
- delta pages y Graph attachment requests;
- lógica de Deleted Items/Inbox/404 y rescans;
- ejecución/retries asociada a esos GETs;
- necesidad de concurrencia alta para Graph.

No elimina necesariamente Event Hubs, normalización, QRadar, storage o observabilidad. Puede añadir:

- licenciamiento Defender for Office 365 si no está incluido;
- un Event Hub dedicado y una configuración Raw Data Export;
- procesamiento de registros de estado y duplicados;
- más metadata cruda antes de allowlist.

### Veredicto económico

- **Si MDO P1/P2/E5 ya está licenciado:** el escenario alternativo probablemente reduce costo variable de Functions/Graph subscriptions y operación. El total puede quedar similar o algo menor que el escenario principal porque Event Hubs/QRadar siguen dominando partes del presupuesto.
- **Si requiere licenciamiento adicional:** el ahorro Azure puede ser menor que el costo MDO. No puede estimarse sin licencia, región y acuerdo Microsoft.

No publicar un ahorro porcentual sin medir: distribución inbound/internal/outbound, attachment rate, licencia MDO, eventos por recipient y parser QRadar.

## Condición de alta probabilidad

La alternativa se considera candidata solo si la PoC demuestra:

1. 100% del corpus sintético entregado produce `EmailEvents` y todas las filas esperadas en `EmailAttachmentInfo`;
2. correo con Inbox rule/purge inmediato sigue visible en el stream;
3. se pueden filtrar solo mensajes con evidencia de entrega y excluir blocked/quarantine-only;
4. attachment types, hashes nulos y wrappers cifrados se documentan;
5. no llega contenido no autorizado a QRadar/Blob;
6. Event Hubs y QRadar absorben latencia, cambios de estado, duplicados y replay.

## Fuentes Microsoft Learn

- [EmailEvents](https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-emailevents-table)
- [EmailAttachmentInfo](https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-emailattachmentinfo-table)
- [Supported streaming event types](https://learn.microsoft.com/en-us/defender-xdr/supported-event-types)
- [Configure Defender XDR to Event Hubs](https://learn.microsoft.com/en-us/defender-xdr/configure-event-hub)
- [Defender Streaming to Storage](https://learn.microsoft.com/en-us/defender-xdr/streaming-api-storage)
