# Impacto esperado en costo

## Resumen

La alternativa Defender probablemente reduce **costo variable de extracción Graph** para inbound/internal, pero no convierte toda la arquitectura en gratis ni necesariamente reduce la factura total.

## Componentes que pueden bajar

- subscriptions/renewal lifecycle para Inbox/Deleted Items de 20.000 mailboxes si esos escenarios dejan de depender de Graph;
- Graph delta calls y páginas;
- requests `/attachments` por cada mensaje inbound/internal con attachment;
- retries, 404/deleted y rescans causados por inbox rules;
- worker execution/GB-seconds y state/checkpoints por mailbox.

Si X% del volumen corresponde a inbound+internal, este componente de extracción puede reducirse aproximadamente en el mismo rango, sujeto a copias, recipients y PoC.

## Componentes que permanecen

- Azure Functions para normalización/estado/dedup;
- Event Hubs, consumer groups, retention/replay;
- Blob staging y observabilidad;
- QRadar DSM/parser, EPS y almacenamiento;
- Graph Sent Items + Message Trace para outbound;
- Security/Operations/monitoring.

## Componentes que pueden subir

- licenciamiento Microsoft Defender for Office 365 si no está incluido;
- throughput por raw email tables si se stream más campos que los requeridos;
- normalización de eventos de estado/delivery updates;
- cualquier solución de retención/forensics adicional.

## Cuándo ahorra

1. MDO ya está licenciado y desplegado.
2. Inbound/internal representa la mayoría del trabajo Graph.
3. La salida Defender elimina la necesidad de 20.000 subscriptions de mailbox para esos escenarios.
4. Event Hubs ya forma parte de la arquitectura QRadar.

## Cuándo no ahorra o cuesta más

1. Defender requiere licencia nueva.
2. Outbound domina y el pipeline Graph no se puede retirar.
3. La organización necesita Sentinel, retención larga o otros componentes no solicitados.
4. El stream raw obliga a duplicar storage/Logs por política.

## Rango prudente

Con MDO ya licenciado, tratar como hipótesis inicial una reducción del costo variable Azure de Functions/Graph-state de **20–60%** para la porción inbound/internal; no extrapolar a la factura total. Event Hubs, QRadar y outbound continúan.

Sin datos reales no se debe rebajar todavía el presupuesto total de USD 500–1.000/mes. La PoC debe medir Graph calls evitadas, Function GB-s, eventos MDO/recipient, payload, QRadar EPS y licencia MDO.
