# Fuentes y límites de la evidencia

- [https://learn.microsoft.com/en-us/defender-xdr/configure-event-hub](https://learn.microsoft.com/en-us/defender-xdr/configure-event-hub)
- [https://learn.microsoft.com/en-us/defender-xdr/supported-event-types](https://learn.microsoft.com/en-us/defender-xdr/supported-event-types)
- [https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-emailevents-table](https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-emailevents-table)
- [https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-emailattachmentinfo-table](https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-emailattachmentinfo-table)
- [https://learn.microsoft.com/en-us/azure/event-hubs/event-hubs-features](https://learn.microsoft.com/en-us/azure/event-hubs/event-hubs-features)
- [https://learn.microsoft.com/en-us/azure/event-hubs/event-hubs-capture-overview](https://learn.microsoft.com/en-us/azure/event-hubs/event-hubs-capture-overview)
- [https://learn.microsoft.com/en-us/azure/storage/blobs/immutable-storage-overview](https://learn.microsoft.com/en-us/azure/storage/blobs/immutable-storage-overview)

La guía de Microsoft describe capacidad y configuración. No demuestra cobertura de la combinación exacta del tenant, versión de QRadar, volumen, red, permisos, ni obligación legal.
