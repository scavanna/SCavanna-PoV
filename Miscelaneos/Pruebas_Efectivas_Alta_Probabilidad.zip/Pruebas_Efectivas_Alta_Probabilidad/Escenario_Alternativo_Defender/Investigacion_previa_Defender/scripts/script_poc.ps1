param(
  [Parameter(Mandatory)][string]$EventHubResourceId,
  [Parameter(Mandatory)][string]$StorageAccountResourceId
)
Write-Host 'Checklist manual: Defender Raw Data Export debe configurarse en el portal con el resource ID, sin secretos en este script.'
Write-Host ('Hub: ' + $EventHubResourceId)
Write-Host ('Archive: ' + $StorageAccountResourceId)
Write-Host 'Antes de producción: verificar Entra RBAC, consumer groups, private endpoint, Capture, retención y esquema real.'
