# Opción 1 — Defender XDR → Event Hubs → QRadar + Storage

**Fecha de investigación:** 17 de noviembre de 2026. **Estado:** diseño para validación; no se ejecutaron cambios en el tenant ni en QRadar.

## Veredicto breve

Es la opción preferida para probar el inventario estructurado continuo. `EmailEvents` y `EmailAttachmentInfo` están soportados en la Streaming API y se pueden enviar a Event Hubs; no demuestra por sí sola cobertura exhaustiva de todos los tipos de adjunto ni compatibilidad del parser QRadar instalado.

## Alcance que cubre

Telemetría de mensajes y adjuntos procesados por Defender; inbound, outbound e intra-org según `EmailDirection`; correlación por `NetworkMessageId`. Ideal para QRadar en tiempo próximo-real, con un consumidor independiente para persistencia.

## Límites críticos

La guía indica que los eventos pueden tardar hasta una hora en aparecer en Event Hubs. Streaming entrega un nuevo registro ante cambios y no ofrece `LatestDeliveryAction`/`LatestDeliveryLocation`. Event Hubs no es archivo de años. `SHA256` suele no estar poblado. La exportación no retroalimenta el histórico anterior a la activación.

## Arquitectura

```mermaid
flowchart LR
  EX[Exchange Online] --> MDO[Defender for Office 365]
  MDO --> XDR[Defender XDR: EmailEvents + EmailAttachmentInfo]
  XDR --> EH[Event Hubs]
  EH --> N[Normalizer: allowlist + dedup]
  N --> QR[QRadar]
  EH --> CAP[Event Hubs Capture: Avro/Parquet]
  CAP --> RAW[Staging restringido]
  N --> W[Blob WORM de metadata]
  MT[Message Trace V2] -. conciliación .-> N
```

## Paso a paso

1. Definir el alcance contractual: direcciones, estados de entrega, correo con adjuntos y tratamiento de tipos especiales; aprobar campos minimizados.
2. Confirmar licencia/implementación real de Defender for Office 365 y datos no nulos en ambas tablas mediante Hunting.
3. Registrar `Microsoft.Insights`; crear namespace/Event Hub con capacidad y particiones basadas en volumen/latencia. Microsoft recomienda Event Hub propio por tipo cuando procede.
4. Asignar los roles documentados al operador y a la identidad del exportador; no compartir secretos en scripts. Separar consumidores `qradar` y `archivo`.
5. En Defender: Settings → Raw Data Export → Add → Event Hubs; seleccionar `EmailEvents` y `EmailAttachmentInfo`; habilitar `EmailPostDeliveryEvents` solo para cambios posteriores.
6. Validar llegada por métricas del hub; identificar envoltura real, `category`/`properties`, lote y esquema efectivo sin exponer PII en logs.
7. Implementar normalización con clave estable por evento y adjunto, checkpoint post-persistencia, backoff, dead-letter y replay. No colapsar adjuntos solo por nombre.
8. Transmitir JSON/CEF/LEEF aprobado al conector QRadar y escribir metadata minimizada en Blob. Activar Capture si se necesita replay barato; después aplicar TTL/WORM al dataset curado.
9. Ejecutar PoC y retirar la regla DLP catch-all solo después de demostrar cobertura y mantenerla como rollback temporal.

## Contrato mínimo de datos

- Correo: `NetworkMessageId`, `InternetMessageId`, timestamp, remitente, destinatario, dirección, acción/ubicación de entrega, asunto solo si está aprobado.
- Adjunto: `FileName`, `FileExtension`, `FileType`, `FileSize`, hash si existe; no se usa nombre+tamaño como identidad única.
- Técnica: versión de esquema, tiempo de evento, ingestión y persistencia, partition/offset o cursor, fuente, estado de normalización.
- Exclusiones por defecto: cuerpo, `bodyPreview`, contenido binario, MIME completo, fragmentos DLP y datos no aprobados en `AdditionalFields`.

## Operación, seguridad y recuperación

- Identidades administradas o certificados; mínimo privilegio; secretos en Key Vault; red privada cuando sea compatible.
- Consumidor idempotente; checkpoint después de persistir; cuarentena de errores; replay documentado; alertas por lag/ausencia/diferencia de conteos.
- Separar staging mutable, dataset curado y archivo WORM. No escribir directamente en un contenedor WORM antes de validar reintentos y semántica de append.
- Aplicar RBAC, cifrado, logging, borrado al vencimiento, legal hold y retención según decisión aprobada de Legal/Compliance.

## Criterios de PoC

1. Mensaje sintético inbound, outbound e intra-org con dos adjuntos, inline, cloud/reference, cifrado si aplica y mensaje adjunto.
2. Contraste exacto entre control de entrada, origen, QRadar y repositorio; no usar `dcount` para certificar.
3. Latencia, duplicados, reordenamiento, caída/reinicio, replay, cambio de esquema, campos no autorizados, nombres con caracteres especiales.
4. Evidencia de cobertura de adjuntos, hash efectivo, reglas QRadar y recuperación de un registro histórico.
5. No avanzar a producción si hay pérdida no explicada, contenido no autorizado, privilegios excesivos o retención no definida.

## Archivos auxiliares

- `consultas.kql`: validación en Hunting cuando aplica.
- `script_poc.ps1`: extracción de parámetros y ejemplo orientativo; no contiene credenciales.
- `matriz_cobertura.csv`: casos de prueba.

## Fuentes Microsoft Learn consultadas

- [https://learn.microsoft.com/en-us/defender-xdr/configure-event-hub](https://learn.microsoft.com/en-us/defender-xdr/configure-event-hub)
- [https://learn.microsoft.com/en-us/defender-xdr/supported-event-types](https://learn.microsoft.com/en-us/defender-xdr/supported-event-types)
- [https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-emailevents-table](https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-emailevents-table)
- [https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-emailattachmentinfo-table](https://learn.microsoft.com/en-us/defender-xdr/advanced-hunting-emailattachmentinfo-table)
- [https://learn.microsoft.com/en-us/azure/event-hubs/event-hubs-features](https://learn.microsoft.com/en-us/azure/event-hubs/event-hubs-features)
- [https://learn.microsoft.com/en-us/azure/event-hubs/event-hubs-capture-overview](https://learn.microsoft.com/en-us/azure/event-hubs/event-hubs-capture-overview)
- [https://learn.microsoft.com/en-us/azure/storage/blobs/immutable-storage-overview](https://learn.microsoft.com/en-us/azure/storage/blobs/immutable-storage-overview)

> Verificación previa a producción: disponibilidad, límites, UI, SKU, licenciamiento y campos pueden cambiar. La documentación oficial no sustituye la PoC del tenant ni la validación del conector QRadar.
