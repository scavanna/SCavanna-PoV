# Exchange Online sin Defender: Azure como orquestador recurrente

## Respuesta corta

Sí puede construirse una arquitectura Azure de consulta recurrente, pero **Exchange Online no expone una fuente nativa metadata-only que garantice todos los adjuntos de todos los mensajes en transporte**. Azure puede hacer polling, checkpoints, colas, reintentos, staging y Log Analytics, pero no crea cobertura que Exchange/Graph no entreguen.

> Resumen ejecutivo comparativo disponible en [RESUMEN_OPCIONES_COMPARATIVA.md](../RESUMEN_OPCIONES_COMPARATIVA.md) y [MATRIZ_OPCIONES_RESUMIDA.csv](../MATRIZ_OPCIONES_RESUMIDA.csv).

## Restricción exacta revisada

- No usar Defender ni su Streaming API.
- Priorizar Exchange Online / Microsoft 365.
- Consultas recurrentes, por ejemplo cada 5 minutos.
- Azure Functions, Storage, Queue/Event Hubs y Log Analytics disponibles.
- Conservar solo metadata: remitente, destinatario, fecha/hora, attachment name/type/size/ID y hash cuando exista.
- No conservar cuerpo ni bytes de adjuntos.

## Opción A — Graph delta + Azure Functions + Queue

### Cobertura

Cubre mensajes que existen en buzones: inbound entregados, sent items outbound e internal según las copias existentes. Los attachment objects exponen `id`, `name`, `contentType`, `size`, `isInline` y `lastModifiedDateTime`. Se debe usar `$select` para evitar `contentBytes`.

### Arquitectura

```mermaid
flowchart LR
  T[Timer Function: cada 5 min] --> D[Graph messages/delta por mailbox]
  D --> Q[Azure Queue: message work]
  Q --> W[Attachment worker]
  W -->|/attachments?$select=id,name,contentType,size,isInline| G[Graph]
  W --> S[Blob staging minimizado]
  W --> C[Checkpoint table: delta/nextLink]
  S --> N[Normalizer/idempotency]
  N --> QR[QRadar]
  N --> LA[Log Analytics/custom table optional]
  E[Queue poison/dead-letter] --> O[Alerting/recovery]
```

### Operación por corrida

1. Inventariar mailboxes objetivo y folders/carpeta inicial.
2. Inicializar `/messages/delta` por usuario/folder con `$select` mínimo.
3. Ejecutar cada 5 minutos; procesar toda la cadena `@odata.nextLink`.
4. No guardar el nuevo `@odata.deltaLink` como checkpoint final hasta encolar/persistir correctamente toda la página.
5. La cola contiene solo una referencia: tenant, mailbox, message ID, direction hint, event time y attempt count. No cuerpo.
6. Worker consulta attachments con `$select=id,name,contentType,size,isInline,lastModifiedDateTime`.
7. Persistir una fila por attachment; si la consulta devuelve 404/deleted, marcar `metadata_unavailable`, no asumir cero adjuntos.
8. Normalizar, deduplicar técnicamente y enviar a QRadar; mover errores a poison queue.
9. Reintentar 429/5xx con backoff; si delta devuelve `410 Gone` o `syncStateNotFound`, iniciar resync controlado.
10. Reconciliar diariamente con Message Trace V2: detecta actividad de transporte que no produjo objeto de mailbox.

### Ventajas

- No necesita Defender.
- Permite strictly metadata-only en el payload, si se evita `contentBytes`.
- Polling de 5 minutos reduce ventana de pérdida operativa.
- Queue desacopla extracción, reintentos y QRadar.
- IDs del attachment son objeto estable por copia/buzón según los datos disponibles.

### Límites

- No ve mensajes rechazados, bloqueados o no depositados.
- Si un mensaje se recibe y elimina definitivamente antes de ser consultado, puede no recuperarse.
- `/delta` es best effort: replays y demoras de consistencia son posibles; token puede expirar.
- Cada mensaje puede aparecer como copias distintas en Inbox/Sent Items y en cada destinatario.
- `Mail.Read` app-only es sensible; debe limitarse a mailboxes mediante Application Access Policy.
- Hash no aparece en el attachment resource; calcular SHA exige descargar bytes, que viola la restricción. Registrar `hash = null/unavailable`.
- El intervalo de 5 minutos no es una garantía temporal ni exactly-once.

## Opción B — Change notifications + delta recovery

Microsoft Graph permite webhooks de cambios para `message` y combinarlos con delta. No elimina el polling, sino que dispara o prioriza una corrida; cada webhook debe escribirse a Queue y validarse.

```mermaid
flowchart LR
  G[Graph message change notification] --> F[Webhook Function]
  F --> Q[Queue]
  Q --> D[Delta worker por mailbox]
  D --> A[Attachment metadata worker]
  A --> O[Blob/QRadar/Log Analytics]
  R[Reconcile timer: cada 5 min / 15 min] --> D
```

Beneficio: menor latencia y menos consultas vacías. Requiere renovación de subscriptions, validación, replays e indisponibilidad del webhook. La corrida recurrente sigue siendo obligatoria como mecanismo de recuperación. Una notificación puede llegar después de que el mensaje ya no exista; delta/Graph metadata puede ser insuficiente.

## Opción C — Journaling temporal + parser

Journaling con scope `All messages` cubre de forma más amplia transporte inbound/outbound/internal, pero viola el requisito si el sistema receptor no puede recibir el contenido original.

Cada journal report incluye el original message sin alterar como attachment. Un parser Azure podría:

1. recibir el mensaje en SMTP broker/archiver externo aprobado;
2. extraer envelope, timestamps, MIME attachment metadata y hash de bytes temporalmente disponibles;
3. enviar solo JSON metadata al siguiente componente;
4. destruir el mensaje original y journal report tras persistir el manifest;
5. monitorizar NDR y alternate journal mailbox.

### Límites bloqueantes

- Se transmite y procesa el contenido, aunque no se conserve a largo plazo.
- No todo mensaje se journaliza antes de las decisiones de cuarentena: cuarentena por mail flow no se journaliza hasta liberación.
- NDR, arbitration mailbox y journal reports no se procesan como mail flow normal.
- Existe duplicación por forks e híbrido.
- Debe usarse un destino externo, no Exchange Online mailbox.
- Cifrado externo puede impedir enumerar MIME attachments sin descifrado.
- Si Privacy/Legal prohíbe acceso temporal, esta opción queda descartada.

## Opción D — Event Hubs/Storage staging entre etapas

Azure no necesita Event Hubs si el volumen es moderado; Queue Storage permite referencias de hasta 64 KB y desacopla. Si se esperan muchos mailboxes o backlog:

- Event Hubs para eventos de trabajo, no para el mensaje;
- Queue para retry/dead-letter;
- Blob para lotes temporales JSONL/Parquet minimizados;
- Table/Cosmos para checkpoint, dedup key y estado;
- Log Analytics solo para una custom table de operaciones y metadata aprobada.

Log Analytics no debe contener cuerpo, bytes, asuntos o logs con payload completo. Tampoco es un datastore de exactamente una vez ni sustituto de una cola durable.

## Modelo de datos mínimo

```json
{
  "eventId": "sha256 de source+tenant+mailbox+messageId+attachmentId",
  "source": "graph-mail",
  "mailbox": "upn",
  "messageId": "immutable Graph ID",
  "internetMessageId": "nullable",
  "sentDateTimeUtc": "nullable ISO-8601",
  "receivedDateTimeUtc": "nullable ISO-8601",
  "sender": "address",
  "recipients": ["addresses"],
  "attachment": {
    "id": "attachment object id",
    "name": "string",
    "contentType": "MIME type",
    "size": 1234,
    "isInline": false,
    "hash": null
  },
  "observedAtUtc": "ISO-8601",
  "deltaTokenGeneration": "opaque identifier",
  "checkpointVersion": 1
}
```

## Qué cambia un polling de 5 minutos

- Mejora detección y reduce backlog.
- Permite reintentos y staging temporal controlado.
- No convierte una fuente de mailbox en fuente de transporte.
- No captura mensajes definitivamente borrados antes de la primera lectura.
- No garantiza cobertura de cifrados/errores no materializados en mailbox.
- No inventa hash si no se leen bytes.

## Recomendación bajo la restricción dada

### Si “todos” = todos los correos depositados

**Aprobar Graph delta/webhook + Azure Queue/Function + Blob + QRadar/Log Analytics.** Es la única vía estrictamente metadata-only más cercana, pero debe declararse el universo como mailbox y no transporte.

### Si “todos” = todo mensaje procesado, incluso rechazado/no entregado

No existe una solución Exchange Online + Azure polling únicamente. Hay que aceptar:

- journaling parser con acceso temporal al mensaje original; o
- gateway/MTA controlado; o
- Defender/telemetría equivalente.

Ninguna de estas ofrece garantía absoluta sin SLA/reconciliación y decisiones de excepción.

## Prueba de decisión

| Pregunta | Opción viable |
|---|---|
| ¿Solo contenido que llegó a mailbox? | Graph delta + Queue |
| ¿Todo lo rechazado también? | Journaling/gateway/telemetría, no Graph |
| ¿Prohibido recibir cuerpo incluso temporalmente? | Graph delta solamente |
| ¿Hash obligatorio? | Graph no; journaling/gateway o lectura bytes sujeta a aprobación |
| ¿Sentido de tiempo? | Conservar sent/received/observed por separado |
| ¿5 minutos requerido? | Timer o notifications + timer recovery |

## Gates de implementación

1. Definir universo: mailbox o transporte.
2. Resolver borrado precoz: retención/hold puede cambiar disponibilidad, con implicaciones legales.
3. Confirmar conjunto de mailboxes, shared mailboxes, grupos y distribución.
4. Aprobar permisos app-only y Application Access Policy.
5. Configurar Queue/poison queue, checkpoints y TTL del staging.
6. Probar 410/token expiry, 429/throttling, webhook outage y 404.
7. Verificar 0 requests que pidan body, MIME o `contentBytes`.
8. Validar parser/QRadar y retención en Log Analytics/Blob.

## Fuentes Microsoft Learn

- [List messages](https://learn.microsoft.com/en-us/graph/api/user-list-messages?view=graph-rest-1.0)
- [List attachments](https://learn.microsoft.com/en-us/graph/api/message-list-attachments?view=graph-rest-1.0)
- [Attachment resource](https://learn.microsoft.com/en-us/graph/api/resources/attachment?view=graph-rest-1.0)
- [Delta query](https://learn.microsoft.com/en-us/graph/delta-query-overview)
- [Outlook change notifications](https://learn.microsoft.com/en-us/graph/outlook-change-notifications-overview)
- [Queue Storage](https://learn.microsoft.com/en-us/azure/storage/queues/storage-queues-introduction)
- [Queue-triggered Functions](https://learn.microsoft.com/en-us/azure/azure-functions/functions-create-storage-queue-triggered-function)
- [Log Analytics data export](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/logs-data-export)
- [Manage retention](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/data-retention-configure)
- [Journaling](https://learn.microsoft.com/en-us/exchange/security-and-compliance/journaling/journaling)
