# Respuesta resumida: frecuencia, Azure y todos los adjuntos

## ¿Una consulta cada 5 minutos resuelve la dependencia de Defender?

Sí, resuelve la necesidad de consultar periódicamente objetos Exchange que están en mailboxes mediante Graph. No resuelve mensajes que nunca entraron a un mailbox ni mensajes eliminados antes de ser consultados. El timer no amplía la fuente.

## ¿Azure Storage temporal/colas y Log Analytics ayudan?

Sí, ayudan a:

- desacoplar extracción e ingestión;
- conservar checkpoints `nextLink`/`deltaLink`;
- reintentar throttling 429 y fallos 5xx;
- manejar poison queues y duplicados;
- guardar staging minimizado antes de QRadar;
- monitorizar ejecución, lag, errores y reconciliación;
- exportar Log Analytics si se requiere un archivo adicional.

No ayudan a recuperar datos que nunca fueron expuestos por Exchange/Graph.

## ¿Puede una task de 5 minutos capturar absolutamente todo?

No. Primero debe definirse “todo” como mensajes depositados y capturables. Incluso en ese alcance, hay eventual consistency, replays, token expiry, 404, throttling, eliminación y copies por mailbox. Una PoC debe certificar el SLO medido, pero no garantiza matemáticamente every message/attachment.

## ¿Defender Streaming garantiza todos los adjuntos?

No. Defender publica eventos y adjuntos observados por su servicio. No ofrece una garantía universal para todos los formatos y estados ni compensación automática de todo el pipeline downstream. El streaming, por sí solo, tampoco reconstruye el pasado anterior a su activación.

## Alternativa preferida sin Defender

Graph `messages/delta` + subscriptions como acelerador + timer de recuperación cada 5 minutos + Queue/Function + staging minimizado + QRadar y Log Analytics. Esta alternativa es metadata-only y automatizable con Azure, pero cubre objetos existentes en mailboxes, no todos los intentos de transporte.

## Si se exige transporte universal

El único cambio que aumenta el universo es introducir una fuente en tránsito: journaling parser que recibe el original temporalmente, gateway/MTA, o telemetría Defender/equivalente. No existe una consulta periódica Exchange-only que produzca inventario universal de adjuntos sin ese paso previo.
