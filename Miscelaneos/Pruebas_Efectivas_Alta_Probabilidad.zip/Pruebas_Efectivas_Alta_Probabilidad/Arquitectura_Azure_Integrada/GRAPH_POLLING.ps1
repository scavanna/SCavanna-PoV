param(
  [Parameter(Mandatory)][string]$UserUpn,
  [Parameter(Mandatory)][string]$DeltaLink,
  [Parameter(Mandatory)][securestring]$AccessToken
)
# PoC conceptual. Production: managed identity/certificate, Graph SDK, retries, queue and durable checkpoint.
$token = [System.Net.NetworkCredential]::new('', $AccessToken).Password
$headers = @{ Authorization = "Bearer $token"; Prefer = 'IdType="ImmutableId"' }
$messageSelect = 'id,internetMessageId,sender,toRecipients,ccRecipients,receivedDateTime,sentDateTime,hasAttachments'
$attachmentSelect = 'id,name,contentType,size,isInline,lastModifiedDateTime'
$next = $DeltaLink
if (-not $next) {
  $next = "https://graph.microsoft.com/v1.0/users/$UserUpn/messages/delta?`$select=$messageSelect"
}
$records = [System.Collections.Generic.List[object]]::new()
while ($next) {
  $page = Invoke-RestMethod -Method Get -Uri $next -Headers $headers
  foreach ($m in @($page.value | Where-Object { $_.hasAttachments -eq $true -and -not $_.'@removed' })) {
    try {
      $au = "https://graph.microsoft.com/v1.0/users/$UserUpn/messages/$($m.id)/attachments?`$select=$attachmentSelect"
      $attachments = Invoke-RestMethod -Method Get -Uri $au -Headers $headers
      foreach ($a in @($attachments.value)) {
        $records.Add([pscustomobject]@{
          mailbox = $UserUpn
          messageId = $m.id
          internetMessageId = $m.internetMessageId
          sentDateTimeUtc = $m.sentDateTime
          receivedDateTimeUtc = $m.receivedDateTime
          sender = $m.sender.emailAddress.address
          toRecipients = @($m.toRecipients.emailAddress.address)
          ccRecipients = @($m.ccRecipients.emailAddress.address)
          attachmentId = $a.id
          name = $a.name
          contentType = $a.contentType
          size = $a.size
          isInline = $a.isInline
          hash = $null
          contentBytesRequested = $false
        })
      }
    } catch {
      throw "Attachment metadata failure for $UserUpn/$($m.id): $($_.Exception.Message)"
    }
  }
  $delta = $page.'@odata.deltaLink'
  $next = $page.'@odata.nextLink'
}
[pscustomobject]@{
  records = $records
  nextDeltaLink = $delta
  # Persist deltaLink only after every queue item in this round was durably committed.
}
