# Validación de cobertura: una prueba integrada

## Universo aprobado

Registrar metadata de attachments de mensajes que tienen una copia en Exchange mailbox:

- inbound: copia en mailbox destinatario;
- internal: copia en mailbox destinatario interno;
- outbound: copia en Sent Items del remitente y estado de transporte conciliado.

Bloqueado/rechazado/no depositado no forma parte del inventario solicitado.

## Casos sintéticos

| Caso | Inbound | Internal | Outbound |
|---|---:|---:|---:|
| Archivo normal | Sí | Sí | Sí |
| Dos adjuntos con mismo nombre | Sí | Sí | Sí |
| Inline image | Sí | Sí | Sí |
| Reference/cloud attachment | Sí | Sí | Sí |
| Attachment de tipo item/message | Sí | Sí | Sí |
| S/MIME/OME/RMS visible | Sí | Sí | Sí |
| Wrapper cifrado sin contenido observable | Registrar wrapper; marcar limitación | Igual | Igual |
| Lista/distribution expansion | Sí | Sí | Sí |
| Shared mailbox | Sí | Sí | Sí |
| Eliminación/Move a Deleted Items antes de poll | Forzar Inbox + Deleted Items | Forzar | Forzar Sent Items delay |
| Permanent delete/purge inmediato | Gate bloqueante si no se recupera | Gate bloqueante | Gate bloqueante |
| Outage de Function/Queue/QRadar | Sí | Sí | Sí |

## Controles por fase

1. **Graph discovery:** existe message ID, direction hypothesis, sent/received, recipients, hasAttachments.
2. **Attachment enumeration:** count exacto, ID, name, MIME, size, inline.
3. **Normalization:** una fila por attachment, dedup key, source, schemaVersion.
4. **Azure/Event Hub:** evento duradero, retry, checkpoint y replay.
5. **QRadar:** evento parseado, event ID consultable, regra/regla SOC disparable.
6. **Outbound reconciliation:** Message Trace status; no confundir DLP/presentación en Sent Items con salida completada.

## Criterio de éxito

- 100% del corpus aprobado depositado aparece una vez lógicamente en staging;
- no faltan filas de attachments observables;
- no hay body/MIME/`contentBytes`;
- duplicados de transport/copy están explicados y controlados;
- salida contiene estado de Message Trace o estado `pending/unresolved`, nunca `sent` asumido;
- QRadar ve/parsea 100% de los eventos sintéticos;
- replay y outage recuperan sin pérdida dentro del SLA de PoC.

Si un caso no puede cumplirse, se reporta como limitación explícita o se reevalúa el universo. No se expande automáticamente la prueba a journaling/Defender.
