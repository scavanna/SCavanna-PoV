# Pruebas efectivas de alta probabilidad

Se mantienen **dos pruebas**:

1. **Principal:** Graph Mail post-delivery para inbound/internal/outbound, con Message Trace para outbound.
2. **Alternativa:** Defender for Office 365 para inbound/internal, Graph Sent Items + Message Trace para outbound. Objetivo específico: medir reducción del riesgo de purge inmediato. Ver [PLAN_DOS_POC.md](PLAN_DOS_POC.md) y [Escenario_Alternativo_Defender](Escenario_Alternativo_Defender/README.md).

## Veredicto

No se propone una prueba distinta por escenario. Se propone **una única arquitectura integrada con un collector común Graph Mail** y una **conciliación específica para outbound**.

| Escenario | Captura primaria | Requisito adicional |
|---|---|---|
| Entrante entregado | Graph Mail sobre el buzón destinatario | Confirmación opcional con Message Trace |
| Interno entregado | Graph Mail sobre el buzón destinatario | Deduplicar por `internetMessageId`; decidir una copia canónica |
| Saliente | Graph Mail sobre Sent Items | Message Trace V2 para confirmar estado de transporte/salida |

El criterio incluye solo mensajes efectivamente depositados. Bloqueados/no depositados quedan fuera por decisión del cliente.

## Arquitectura objetivo

```mermaid
flowchart LR
  IN[Inbound delivered] --> MB1[Recipient mailbox]
  INT[Internal delivered] --> MB2[Recipient mailbox]
  OUT[Outbound] --> SI[Sent Items]
  MB1 --> GM[Microsoft Graph messages/delta + attachments metadata]
  MB2 --> GM
  SI --> GM
  GM --> QW[Azure Queue: work and retry]
  QW --> FN[Azure Functions: normalize and deduplicate]
  FN --> ST[Blob staging minimized]
  FN --> EH[Event Hubs normalized mailbox-events]
  MT[Message Trace V2 periodic] -. outbound/transport status .-> FN
  EH --> QR[QRadar consumer: Azure Event Hubs protocol + validated DSM]
  ST --> RE[Recovery/replay]
  FN --> LA[Log Analytics: operations and approved metadata]
```

## Cómo llega a QRadar

**QRadar no consulta Graph ni Exchange directamente en la propuesta.** La aplicación Azure normaliza los eventos y publica en un Event Hub dedicado. QRadar los consume mediante su protocolo de Microsoft Azure Event Hubs configurado con:

- consumer group exclusivo de QRadar;
- autenticación compatible con la instalación;
- checkpoint persistente propio;
- formato JSON/LEEF/CEF estable;
- DSM/parser validado contra el payload;
- red, TLS/puertos y credenciales compatibles con la política BNA.

Event Hubs es un buffer/event stream; es de modelo pull. QRadar es el consumidor. La aplicación Azure no “envía un correo” al SIEM ni debe escribir directamente en una API QRadar no aprobada.

Blob cumple dos papeles:

1. staging/replay del dataset normalizado;
2. almacenamiento opcional de checkpoints si lo exige la versión del conector de QRadar.

No confundir Blob de checkpoints con evidencia histórica. Log Analytics sirve para métricas, errores y consultas aprobadas, no como dependencia de QRadar.

## Contrato de evento propuesto

Una fila por attachment, sin cuerpo:

- `eventId`
- `scenario`: inbound/outbound/internal
- `mailboxUpn`, `folder`
- `messageId`/immutable Graph ID
- `internetMessageId`
- `sender`, `toRecipients`, `ccRecipients`, `recipientCopy`
- `sentDateTimeUtc`, `receivedDateTimeUtc`, `observedAtUtc`
- `attachmentId`, `name`, `contentType`, `size`, `isInline`
- `transportStatus`, `transportReceivedUtc`, `messageTraceId` solo cuando Message Trace lo resuelve
- `schemaVersion`, `source`, `dedupKey`

Hash: no disponible en Graph attachment metadata sin leer bytes. Se deja `null/unavailable`. El ID de attachment identifica la copia/objecto en el buzón; no es un hash criptográfico ni ID universal de transporte.

## Flujo de ejecución

1. Inventariar mailboxes y folders. Definir si inbound/internal se captura en destino. Outbound se captura en Sent Items.
2. Crear app con el menor permiso Graph compatible, limitar mailboxes con Application Access Policy y usar managed identity/certificate.
3. Inicializar delta por mailbox/folder con `$select` mínimo; subscriptions aceleran detección, timer cada 5 minutos mantiene recuperación.
4. Encolar solo referencias, no contenido.
5. Consultar attachments con `$select=id,name,contentType,size,isInline,lastModifiedDateTime`.
6. Aplicar idempotencia por mailbox+message+attachment ID; guardar múltiples recipient copies como copias separadas cuando el requisito operacional lo necesite.
7. Persistir staging y publicar al Event Hub; no avanzar checkpoint hasta commit duradero.
8. Ejecutar conciliación Message Trace V2 para outbound por ventanas, conservando los estados y timestamps separados.
9. QRadar consume con su consumer group; validar parser y regla. Comparar conteos Azure↔QRadar.
10. Alertar por lag, queue poison, parser drops, token expiry, 404/deleted, throttling y divergencias de Message Trace.

## Alta probabilidad, pero no garantía absoluta

Sí debe probarse porque usa fuentes estables y alcance post-delivery definido. No garantiza:

- mensaje borrado o purgado permanentemente antes de la primera consulta;
- eliminación inmediata por Inbox rule; solo queda cubierto si el objeto permanece en Deleted Items u otra carpeta rastreada;
- attachments dentro de contenedor cifrado no descifrable;
- hash criptográfico sin leer bytes;
- IDs universales entre copias y transport;
- exactly-once extremo a extremo; se diseña at-least-once con dedup.

## Entregables de prueba

- `01_Validacion_cobertura.md`
- `02_Diseno_QRadar.md`
- `03_Plan_PoC_y_criterios.md`
- Componentes técnicos reutilizables: `Componentes/Graph_Mail_Delta`, `Componentes/MessageTraceV2` y `Arquitectura_Azure_Integrada`.
