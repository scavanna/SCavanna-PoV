# Integración propuesta con IBM QRadar

## Patrón recomendado

```mermaid
flowchart LR
  G[Graph collector] --> A[Function normalizer]
  A --> B[Blob staging/replay]
  A --> E[Event Hub: bna-mail-attachments]
  E -->|pull consumer group qradar| Q[QRadar Azure Event Hubs protocol]
  Q --> D[QRadar DSM/parser and rules]
  E --> C[Event Hubs Capture/alternate consumer]
  L[Monitoring] --> A
```

1. La aplicación publica eventos JSON minimizados en Event Hubs.
2. QRadar obtiene esos eventos como consumidor independiente.
3. QRadar usa un consumer group propio y checkpoints propios. No debe compartirlo con archivo, monitor o procesos de prueba.
4. Blob normalizado queda como respaldo; QRadar no necesita leerlo si Event Hubs funciona.
5. Si el protocolo QRadar usa Blob para checkpoints, ese contenedor se separa del Blob histórico.

## Formato de evento

Preferir JSON lineal estable, una fila por attachment, con `schemaVersion`. CEF/LEEF solo si el conector/DSM de la versión instalada lo procesa mejor. No enviar body, MIME, preview, `contentBytes`, asunto salvo autorización, ni campos Graph opacos.

## Dependencias QRadar a validar

- versión instalada del protocolo Azure Event Hubs;
- compatibilidad con Event Hub/namespace, TLS, AMQP, Entra ID o SAS;
- soporte para JSON/LEEF/CEF;
- DSM personalizado o extensión del log source;
- consumer group y contenedor de checkpoints;
- puertos y resolución de nombres/proxy;
- reglas, time stamps, event ID, attachment names con escaping;
- cadencia de poll, backlog/lag y pérdida por parser.

## Criterio de aceptación end-to-end

- 100% de los eventos sintéticos de la PoC publicados en Event Hubs aparecen en QRadar;
- 100% se parsean en los campos esperados;
- no se recibe body/MIME/`contentBytes`;
- rebase/restart/QRadar outage permite replay dentro de retención;
- los duplicados técnicos se deduplican por `eventId` o quedan identificables;
- QRadar no comparte consumer group con otros consumidores;
- p95 de latencia medido y aceptado por SOC.

## Alternativa de contingencia

Si la instalación QRadar no puede consumir el Event Hub normalizado con el parser requerido, usar archivos Blob incrementales en un formato soportado por un log source existente. Esta ruta requiere validarla como segunda configuración, no asumir que el mismo DSM consume indistintamente Event Hubs y Blob.
