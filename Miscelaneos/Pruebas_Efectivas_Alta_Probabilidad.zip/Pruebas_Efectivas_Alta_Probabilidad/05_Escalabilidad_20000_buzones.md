# Escalabilidad: 20.000 buzones × 50 correos/día

## Volumen base

20.000 × 50 = **1.000.000 de mensajes/día**, promedio **11,6 mensajes/segundo** o **694/minuto**, si están distribuidos uniformemente durante 24 horas. Este promedio no representa picos de oficina, campañas o distribución.

Variables que faltan para dimensionar:

- porcentaje que son inbound, outbound e interno;
- porcentaje con uno o más adjuntos;
- adjuntos promedio por mensaje;
- destinatarios promedio y expansión de listas;
- horario/picos por región;
- shared mailboxes, room/resource y servicios;
- duplicados Sent Items/Inbox que el diseño decide conservar;
- latencia objetivo y tiempo máximo de recuperación;
- eventos QRadar y tamaño medio del JSON.

## ¿Es viable técnicamente?

**Sí como arquitectura Azure de producción, pero no puede aprobarse todavía como solución garantizada.**

La carga de datos al final no parece extrema para Azure/Event Hubs si el payload es metadata-only. El cuello de botella no es el almacenamiento final sino:

1. consultas a Microsoft Graph;
2. número de buzones/suscripciones;
3. volumen de peticiones adicionales para `attachments`;
4. throughput de QRadar y su parser;
5. recuperación frente a throttling, token expirado y borrado inmediato.

Microsoft Graph no publica un máximo fijo utilizable para certificar esta carga; aplica throttling dinámico y responde `429` con `Retry-After`. La aplicación debe respetarlo. Microsoft recomienda Data Connect para extracción masiva; sin embargo, aquí se necesita captura continua/casi en tiempo real y Data Connect no sustituye automáticamente este flujo de attachments.

## ¿Cuántas llamadas hace falta?

Estimación inicial, antes de optimización:

- **1.000.000 mensajes/día**.
- Solo los mensajes con `hasAttachments=true` requieren al menos una llamada a `/attachments`.
- Si 30% tienen attachment: 300.000 consultas attachment/día, promedio 3,5/s.
- Si 100% tienen attachment: 1.000.000 consultas/día, promedio 11,6/s.
- Delta/notifications, reintentos, paginación, subscriptions, folders y reconciliación se suman.
- Más de una copia: si se registra sender Sent Items y recipient Inbox del mismo correo, aumenta el volumen lógico, aunque luego se deduplique el objeto de negocio.

No hacer un cron global que consulte los 20.000 buzones cada 5 minutos sin filtrar cambios: eso produciría **20.000 delta calls cada 5 minutos**, es decir 66,7 calls/s solo para polling de buzón vacío o con cambios, además de pages y attachments. Ese patrón es innecesario, más expuesto a throttling y aumenta costo.

## Diseño recomendado a escala

```mermaid
flowchart LR
  EX[20.000 mailboxes] --> N[Graph subscriptions per mailbox/folder]
  N --> I[Notification ingestion and dedup]
  I --> Q[Queue partitioned by mailbox hash]
  Q --> W[Function workers: concurrency cap]
  W --> G[Graph delta + attachment metadata]
  W --> R[Retry with Retry-After]
  G --> NORM[Normalizer and dedup]
  NORM --> EH[Event Hubs partitioned]
  EH --> QR[QRadar consumer group]
  W --> CK[Checkpoint/state per mailbox]
  S[Staggered timer recovery] --> Q
  L[Lifecycle and subscription renewal] --> N
```

Patrón:

1. Subscription Graph por mailbox/folder realmente analizada; las notificaciones disparan trabajos.
2. Debounce/agrupación por mailbox para no ejecutar una delta por cada notificación individual.
3. Queue particionada por hash de mailbox para controlar concurrencia y orden local.
4. Workers con límite de concurrencia configurable, backoff usando `Retry-After` y circuit breaker.
5. Timer escalonado de recuperación, no 20.000 consultas simultáneas cada 5 minutos.
6. Lifecycle notifications, renovación y reconstrucción de subscriptions.
7. Batch HTTP solo donde Microsoft Graph lo permita; cada request dentro del batch conserva sus límites y no evita throttling.
8. Event Hubs con particiones suficientes según throughput medido, consumer groups separados y retention temporal para replay.
9. QRadar prueba el parser a picos reales; si no absorbe, la cola/Event Hub contiene backlog y no se debe perder el checkpoint.

## Suscripciones

La documentación de Outlook establece un límite máximo de 1.000 suscripciones activas por mailbox, sumando todas las aplicaciones. Usar una suscripción por recurso/folder normalmente evita ese límite, pero no reduce el trabajo operativo:

- 20.000 mailboxes implican aproximadamente 20.000 suscripciones si se monitoriza cada usuario;
- si se monitorean Inbox + Sent Items + Deleted Items, puede haber varias por mailbox;
- las subscriptions expiran y requieren renovación;
- lifecycle notifications deben disparar recreación/resync;
- las cuotas globales o límites de implementación del tenant deben comprobarse en la PoC;
- subscriptions no son datos duraderos ni sustituto de checkpoints/delta.

Para reducir carga y riesgo se puede consolidar por scope solo si se eligen grupos, shared mailboxes o caminos de mensajería concretos. Graph no permite tratar 20.000 buzones como una sola `Inbox` genérica.

## Cambios/reconfiguraciones necesarios

### En Microsoft Entra ID

- Registrar una aplicación o managed identity con cliente/servicio propio.
- Conceder consentimiento administrativo al permiso mínimo de aplicación compatible: en general `Mail.Read` o una alternativa de lectura básica si satisface todos los campos.
- Decidir certificado o managed identity; no usar client secrets de larga duración en scripts/productivos.
- Registrar endpoint/validación para subscriptions.

### En Exchange Online

- Crear una asignación RBAC for Applications o, donde aún se use, la política Application Access legacy adecuada, para que la app solo acceda a los mailboxes autorizados.
- Confirmar que el role/management scope cubre 20.000 mailboxes objetivo, incluidos shared mailboxes si aplican.
- Inventariar Inbox rules, carpetas y retención. Si existe purge inmediato, modificar la regla/política o aceptar que Graph-only no puede dar alta probabilidad.
- Confirmar Sent Items para outbound. En shared mailboxes, validar si las copias de enviados se guardan en Sent Items de la shared mailbox o del remitente y ajustar el alcance.
- No es obligatorio reconfigurar reglas DLP ni mail flow para el collector propuesto.
- No modificar conectores o routing si la fuente sigue siendo mailbox.

### En Azure

- Function App/Premium o App Service/Container Apps según volumen y cold-start; el plan debe soportar concurrency, red y escala medida.
- Queue/Event Hubs, Storage, checkpoint/state store, Key Vault, Private Endpoints cuando correspondan.
- Application Insights/Log Analytics solo con metadata y telemetría aprobadas.
- Alertas por lag, 429, 5xx, 404/deleted, poison queue, subscription expiry y p95.

### En QRadar

- Configurar log source/protocol, DSM/parser, consumer group, authentication, checkpoints y red.
- Dimensionar EPS/eventos, almacenamiento histórico y parser.

## ¿Funciona a 1 millón/día?

**No puede afirmarse sin PoC.** Se debe clasificar como:

- **datos Azure/QRadar:** razonablemente dimensionables, sujeto a EPS/tamaño/picos;
- **Graph REST continuo:** viable, pero condicionado a throttling, permisos, subscriptions y race de borrado;
- **costo/operación de 20.000 subscriptions:** no trivial;
- **Message Trace V2 outbound:** debe ejecutarse por ventanas agregadas, no por mensaje; validar ventana, resultados parciales y throttling;
- **garantía universal de cero pérdida:** no disponible; se diseña at-least-once, dedup y reconciliación.

## PoC de escala obligatoria

Antes de producción:

1. Medir al menos 50-100 mailboxes durante una jornada normal o usar carga sintética autorizada.
2. Obtener estos valores reales: mensajes con attachment, attachments/message, p50/p95 payload, notification-to-read, 404 rate, 429 rate, picos por 5 minutos y folders afectados.
3. Ejecutar una prueba de mayor escala controlada con miles de mailboxes, sin multiplicar lecturas productivas.
4. Extrapolar linealmente solo como hipótesis; validar el punto de throttling real y capacidad de backoff/recovery.
5. Simular outage de 1, 4 y 24 horas; medir backlog, tiempo de recuperación y expiración de subscriptions.
6. Probar QRadar a picos, no al promedio diario.
7. Confirmar que la PoC conserva cero body/MIME/`contentBytes`.

## Gates go/no-go específicos

- `GO`: p95 Graph read/attachment cumple SLA; 429 se recupera; no backlog permanente; QRadar absorbe pico; race de borrado aceptable; costo y 20.000 subscriptions operables.
- `NO-GO / rediseño`: no se puede limitar Graph a 404/race, throttling continuo, permisos globales inaceptables, QRadar no absorbe, o costo de subscriptions/renovación supera el beneficio.

Si falla el gate, debe reconsiderarse una fuente pre-buzón/journaling/gateway. No debe “aumentar más concurrencia” como única respuesta al throttling.

## Fuentes

- [Microsoft Graph throttling](https://learn.microsoft.com/en-us/graph/throttling)
- [Delta query](https://learn.microsoft.com/en-us/graph/delta-query-overview)
- [Change notifications for Outlook](https://learn.microsoft.com/en-us/graph/outlook-change-notifications-overview)
- [RBAC for Applications in Exchange Online](https://learn.microsoft.com/en-us/exchange/permissions-exo/application-rbac)
- [Application Access Policies, legacy](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access)
- [Event Hubs features](https://learn.microsoft.com/en-us/azure/event-hubs/event-hubs-features)
- [Get-MessageTraceV2](https://learn.microsoft.com/en-us/powershell/module/exchangepowershell/get-messagetracev2?view=exchange-ps)
