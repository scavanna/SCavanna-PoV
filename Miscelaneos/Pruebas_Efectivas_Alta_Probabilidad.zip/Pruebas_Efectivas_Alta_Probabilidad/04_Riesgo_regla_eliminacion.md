# Riesgo: regla del buzón que elimina el correo inmediatamente

## Respuesta directa

La solución propuesta **puede perder el attachment** si el mensaje se elimina permanentemente antes de que Graph y el worker lo lean. Un timer de 5 minutos, por sí solo, no garantiza verlo.

No debe confundirse:

1. **Mover a Deleted Items:** en general conserva el objeto y permite rastrearlo si también se sincroniza Deleted Items.
2. **Permanently delete / purge:** el objeto puede dejar de existir antes de consultar `/attachments`.
3. **Regla cliente o proceso externo:** puede borrar o descargar después de la entrega con tiempos no controlados por Exchange.

## Qué ofrece la arquitectura

- `messages/delta` se ejecuta por carpeta. Si solo se sincroniza Inbox, una regla que mueve el correo a otra carpeta produce un cambio de eliminación en Inbox; la metadata de una eliminación puede contener solo el ID, no el attachment metadata.
- Si se sincroniza también Deleted Items, el correo movido puede aparecer en esa carpeta y recuperarse mientras exista.
- Una subscription/change notification reduce latencia, pero no ofrece exactly-once ni garantiza que el worker gane la carrera contra la eliminación.
- Si llega una notificación de creación y el worker consulta el mensaje más tarde, Graph puede responder 404 porque ya no existe. La notificación no reemplaza automáticamente la colección de attachments.
- Delta puede representar replays o cambios resumidos; no debe asumirse que siempre conserva cada transición temporal completa de un objeto creado y borrado en el mismo intervalo.

## Escenarios

| Acción real | Probabilidad de captura con Graph | Condición |
|---|---|---|
| Regla mueve a Deleted Items | Alta/Media | Se consulta Inbox y Deleted Items; se mantiene el mensaje suficiente tiempo |
| Regla mueve a otra carpeta | Media/Alta si se rastrea | Se debe descubrir y sincronizar esa carpeta |
| Regla borra permanentemente, pero el cliente tarda | Media/Baja | Eventualidad; notification puede adelantar, pero no hay garantía |
| Purge/permanent delete inmediato | Baja | El attachment puede no estar disponible cuando el worker lo consulte |
| Proceso descarga attachment y después conserva el correo | Alta | Mensaje permanece accesible a Graph |
| Correo se retiene en Recoverable Items por política | Potencial; requiere validación | La disponibilidad de Graph para ese estado no debe asumirse; probar acceso y retención |

## Mitigaciones ordenadas

1. **No sincronizar solo Inbox.** Descubrir y sincronizar todas las folders relevantes: Inbox, Deleted Items y folders destino permitidas. Si la regla mueve, correlacionar IDs inmutables.
2. **Combinar notifications + timer muy corto.** La notification dispara procesamiento inmediato; el timer/delta cada 5 minutos sirve para recuperación, no como primera línea.
3. **Persistir la metadata apenas llega la notificación/delta.** Queue solo referencias; el worker debe consultar attachments inmediatamente. Tratar 404 como gap material, no como “sin attachments”.
4. **Acordar retención mínima antes de purge.** Por ejemplo, no purgar permanentemente durante una ventana acordada. Esta es una condición operativa que debe probarse; no se fija un tiempo sin decisión de BNA.
5. **Deshabilitar o rediseñar reglas que procesan y eliminan mensajes críticos antes de la captura**, si Privacy/Operations lo permite.
6. **Si permanent delete inmediato es obligatorio, la fuente debe estar antes del buzón.** Graph-only ya no satisface alta probabilidad. Las opciones son journaling o gateway/transport telemetry, pero introducen procesamiento de contenido o una dependencia adicional.

## Veredicto sobre la prueba propuesta

- Si “descarga y borra” significa **mover a Deleted Items y conservar allí**, se puede probar Graph con alta probabilidad cubriendo Inbox + Deleted Items + subscriptions.
- Si significa **purge/permanent delete inmediato**, la prueba Graph-only deja de ofrecer alta probabilidad. Debe modificarse la regla/retención o agregarse una fuente pre-delivery. La segunda PoC propuesta usa Defender `EmailEvents` + `EmailAttachmentInfo` para inbound/internal, precisamente para medir si elimina ese gap sin perder el esquema normalizado ni el destino QRadar.

## Prueba obligatoria antes del go/no-go

Enviar correos sintéticos del remitente objetivo y ejecutar la regla en estos cuatro casos:

1. mover a Deleted Items;
2. permanent delete;
3. mover a carpeta personal;
4. descarga por proceso externo y eliminación.

Medir:

- hora de entrega;
- hora de notificación Graph;
- hora de primer delta;
- hora de attachment GET;
- momento de deletion;
- códigos 404/410 y tiempo hasta `@removed`;
- aparición en Deleted Items o carpeta destino;
- cantidad exacta de attachments recuperados.

Un solo caso sintético no certifica la condición. Debe repetirse bajo carga y outage del worker.

## Decisión de documentación

El riesgo forma parte de los gates de la prueba. No debe afirmarse “registra todos los adjuntos entregados” hasta demostrar el comportamiento del tipo de regla y retención configurados en BNA.
